import numpy as np
import xlrd
from matplotlib import pyplot as plt
import xlrd3 as xr
import pandas as pd
import matplotlib.pyplot as plt
import torch

file_location1="附件1.xlsx"
data1=xr.open_workbook(file_location1)
sheet1 = data1.sheet_by_index(0)
lie1=sheet1.nrows
hang1=sheet1.ncols


file_location2="附件2.xlsx"
data2=xr.open_workbook(file_location2)
sheet2 = data2.sheet_by_index(0)
lie2=sheet2.nrows
hang2=sheet2.ncols

dic = {}
for i in range(1,lie1):
   id=str(sheet1.cell_value(i, 0))
   info=str(sheet1.cell_value(i,3))
   # str(sheet1.cell_value(i,1))+' '+str(sheet1.cell_value(i,2))
   dic[id] = info


plt.rcParams['font.sans-serif'] = ['SimHei'] # 用来正常显示中文标签SimHei
plt.rcParams['axes.unicode_minus'] = False # 用来正常显示负号
sell_time_num = {}
for i in range(1, lie2 ,4):#步长为5随机抽样12w份
   id = str(sheet2.cell_value(i,2))
   if dic[id] == "花叶类":
      sell_num = sheet2.cell_value(i, 3)
      price = str(sheet2.cell_value(i, 4))
      if price in sell_time_num:
         sell_time_num[price] += float(sell_num)
      else:
         sell_time_num[price] = float(sell_num) # 获取各个时间段总销量


x_data_pre = []
y_data_pre = []
for key, value in sell_time_num.items(): #获取需要拟合的数据 即 销量与成本定价
   x_data_pre.append(float(key))
   y_data_pre.append(value)
   plt.bar(float(key), value, color="orange")
   plt.scatter(float(key), value)

x_data = torch.tensor(x_data_pre)
y_data = torch.tensor(y_data_pre)        #将字典里的数据转为tensor


x_data.requires_grad = True
y_data.requires_grad = True


w = torch.tensor([-1.0])
b  = torch.tensor([1.0]) # 假设的数据
lr = 0.0001


w.requires_grad = True
b.requires_grad  = True


def forward(x):
   return w * x  + b


def loss(x, y):              #||x||均方损失
   # print(x, y)
   y_pred = forward(x)
   # print(y_pred)
   return (y_pred - y) ** 2


for epoch in range(1000):
   for x, y in zip(x_data, y_data):
      l = loss(x, y)
      l.backward()
      w.data = w.data - lr * w.grad.data
      b.data  =  b.data - lr *  b.grad.data

      w.grad.data.zero_()
      b.grad.data.zero_()

   print("progress", epoch, l.item())


w.requires_grad = False
b.requires_grad  = False # 取消求导追踪防止画不了图

xxx = np.arange(0,40,0.01)
yyy = []
for i in xxx:
   yyy.append(forward(i))
   #画出拟合后的二次函数
plt.plot(xxx,yyy)
plt.margins(x=0)

plt.xlabel="时间"
plt.ylabel="销售量"
plt.title("花叶类")
plt.show()






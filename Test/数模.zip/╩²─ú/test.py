import numpy as np
import torch
import matplotlib.pyplot as plt


def forward(x):
    return w1 * (x * x) + w2 * x + b
w1 = torch.tensor([-1.0])
w2 = torch.tensor([10.0])
b = torch.tensor([0.0]) # 假设的数据
w1.requires_grad = True
w2.requires_grad = True
b.requires_grad = True


x_data = torch.tensor([1.0, 2.0, 1.0, 2.0])
y_data = torch.tensor([2.0, 4.0, 2.0, 4.0])


def loss(x, y):              # ||x||均方损失
   # print(x, y)
   # y_pred = forward(x)
   print(y_pred)
   return (y_pred - y) ** 2


for epoch in range(1000):
   for x, y in zip(x_data, y_data):
      l = loss(x, y)
      l.backward()
      w1.data = w1.data - 0.01 * w1.grad.data
      w2.data = w2.data - 0.01 * w2.grad.data
      b.data = b.data - 0.001 * b.grad.data

      w1.grad.data.zero_()
      w2.grad.data.zero_()
      b.grad.data.zero_()

   print("progress", epoch, l.item())

w1.requires_grad = False
w2.requires_grad = False
b.requires_grad = False


xxx = np.arange(-40, 40, 0.01)
yyy = []
for i in xxx:
   yyy.append(forward(i))
   #画出拟合后的二次函数
plt.plot(xxx, yyy)
plt.show()
import numpy as np
import xlrd
from matplotlib import pyplot as plt
import xlrd3 as xr
import pandas as pd
import matplotlib.pyplot as plt


file_location1="附件1.xlsx"
data1=xr.open_workbook(file_location1)
sheet1 = data1.sheet_by_index(0)
lie1=sheet1.nrows
hang1=sheet1.ncols


file_location2="附件2.xlsx"
data2=xr.open_workbook(file_location2)
sheet2 = data2.sheet_by_index(0)
lie2=sheet2.nrows
hang2=sheet2.ncols


dic = {}
for i in range(1,lie1):
   id=str(sheet1.cell_value(i, 0))
   info=str(sheet1.cell_value(i,3))
   # str(sheet1.cell_value(i,1))+' '+str(sheet1.cell_value(i,2))
   dic[id] = info


plt.rcParams['font.sans-serif'] = ['SimHei'] # 用来正常显示中文标签SimHei
plt.rcParams['axes.unicode_minus'] = False # 用来正常显示负号
sell_time_num = {}
for i in range(1, lie2, 5):#步长为5随机抽样12w份
   id = str(sheet2.cell_value(i,2))
   if dic[id] == "水生根茎类":
      # print(sheet2.cell_value(i,1))
      dt = xlrd.xldate_as_datetime(sheet2.cell_value(i, 0), 1)
      # print(dt.month , ' ',dt.day)
      time = int(dt.month)  #每一天的分钟
      sell_num=sheet2.cell_value(i,3)
      if time in sell_time_num:
         sell_time_num[time] += float(sell_num)
         # print(sell_time_num[time])
      else:
         sell_time_num[time] = float(sell_num)#获取各个时间段总销量

for key, value in sell_time_num.items():
   plt.bar(int(key), value, color="orange")


date = []
word = []


for i in range(1, 13):
   date.append(i)
   word.append(str(i) + "月" )
plt.xticks(date, word)
plt.xlabel="时间"
plt.ylabel="销售量"
plt.title("水生根茎类")
plt.show()





